Config = {}


Config.item = {
    boire = {
        {itemlabel = "Eau", itemname = "water", price=100, photo="img/water.png"},
        {itemlabel = "Coca", itemname = "coca", price=100, photo="img/cola.png"},
        {itemlabel = "Sprite", itemname = "sprite", price=100, photo="img/sprite.png"},
        {itemlabel = "Red Bull", itemname = "red", price=100, photo="img/redbull.png"},
        {itemlabel = "Ice-Tea", itemname = "icetea", price=100, photo="img/icetea2.png"},
        {itemlabel = "Jus de mangue", itemname = "jsm", price=100, photo="img/juice.png"},
        {itemlabel = "Vodka", itemname = "vodka", price=100, photo="img/vodka.png"},
        {itemlabel = "Rhum", itemname = "rhum", price=100, photo="img/Rhum.png"},
        {itemlabel = "Vin", itemname = "vin", price=100, photo="img/wine.png"},
        
    },
    manger = {
        {itemlabel = "Burger", itemname = "burger", price=100, photo="img/burger.png"},
        {itemlabel = "Frite", itemname = "fries", price=100, photo="img/friesxl.png"},
        {itemlabel = "Pop Corn", itemname = "popcorn", price=100, photo="img/popcorn.png"},
        {itemlabel = "Hot-Dog", itemname = "hotdog", price=100, photo="img/hotdog.png"},
        {itemlabel = "Taco", itemname = "taco", price=100, photo="img/taco.png"},
        {itemlabel = "Pizza", itemname = "pizza", price=100, photo="img/pizza.png"},
        {itemlabel = "Nuggets", itemname = "tavuknuggets", price=100, photo="img/tavuknuggets.png"},
        {itemlabel = "Ramen", itemname = "ramen", price=100, photo="img/ramen.png"},
        {itemlabel = "Tacos", itemname = "tacot", price=100, photo="img/tacot.png"},
    },
    autre = {
        {itemlabel = "Telephone", itemname = "telephone", price=100, photo="img/phone.png"},
        {itemlabel = "Carte Sim", itemname = "sim", price=100, photo="img/simcard.png"},
        {itemlabel = "Radio", itemname = "radio", price=100, photo="img/radio.png"},
        
    }
}